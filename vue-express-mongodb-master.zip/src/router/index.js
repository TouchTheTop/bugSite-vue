import Vue from 'vue'
import VueRouter from 'vue-router'
import Home from 'pages/Home'
import About from 'pages/About'
import Add from 'pages/Add'
import Detail from 'pages/Detail'
import Doc from 'pages/Doc'
import Login from 'pages/Login'

Vue.use(VueRouter)


// const routes = {
//   '/': 'Home',
//   '/about': 'About',
//   '/doc':'Doc',
//   '/add':'add',
//   '/detail/:id':'Detail'
// }

const routes = [
  { path: '/',name:"/", component: Home },
  { path: '/login',name:"login", component: Login },
  { path: '/about',name:"about", component: About },
  { path: '/doc',name:"doc", component: Doc },
  { path: '/add', name:"add",component: Add },
  { path: '/detail/:id',name:"detail", component: Detail },
  { path: '/edit/:id',name:"edit", component: Detail },
]


export default new VueRouter({
    routes:routes
});