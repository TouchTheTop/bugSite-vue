<template>
  <div>
    <p>Welcome home</p>
  </div>
</template>

<script>
  import MainLayout from '../layouts/Main.vue'

  export default {
    components: {
      MainLayout
    }
  }
</script>
