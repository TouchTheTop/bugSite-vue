<template>
  <div>
    <p>添加文章 </p>
    <div class="types_choose">
    <a href="#" id="">JAVA</a>
    <a href="#" id=""class="active">前端</a>
    <a href="#" id="">Android</a>
    <a href="#" id="addtag" class="fa fa-plus-circle add"  ref="addtag"></a>
</div>
    <div class="add content" ref="addbox">
      <form >
        <input type="text" name="title" class="title" placeholder="请输入标题"  v-model="title">
        <div id="editorElem" class="asset" @paste="onPasteEvent($event)">

        </div>
        <input type="hidden" name="asset" :value="editorContent">
        <div class="submit">
          <button type="submit" @click.prevent="add">提交</button>
        </div>
      </form>
    </div>

  </div>
</template>

<script>
  import MainLayout from '../layouts/Main.vue'
  import E from 'wangeditor'
  export default {
    data(){
      return {
        editorContent: '',
        editor:'',
        title:'',
        asset:''
      }
    },
    mounted() {
      var editor = new E('#editorElem')
      editor.customConfig.onchange = (html) => {
        this.editorContent = html
      }
      editor.create();
      this.editor = editor;

    },
    methods:{
      add: function() {
        this.$http.post('/api/doc', {
          title:this.title,
          asset:this.editorContent,
          img:$('#editorElem').find('img').eq(0).attr('src')
        }).then((response) => {
                // success callback
                window.location.reload();
                this.$router.push(`/doc`)
                toastr.success(res.data.msg);
              }, (response) => {
                // error callback
              });

      },
      addtag(e){
          this.$refs.addtag.append("<input type='text' />");
      },
      onPasteEvent(e){

       var clipboard = e.clipboardData;
       for(var i=0,len=clipboard.items.length; i<len; i++) {
        if(clipboard.items[i].kind == 'file' || clipboard.items[i].type.indexOf('image') > -1) {
          var imageFile = clipboard.items[i].getAsFile();
          var form = new FormData();
          form.append('t', 'ajax-uploadpic');
          form.append('file', imageFile);
          var callback = G.uploadpicCallback || function(type, data){};
          let config = {
            headers:{'Content-Type':'application/x-www-form-urlencoded'}
          };  //添加请求头
          this.$http.post('/api/upimg',form,config)
          .then(res=>{
            console.log(res.data);
            this.editor.txt.append('<img src="'+res.data.path.split('static\\')[1]+'"></img>')
          })
          .catch(e => {
            console.log(e);
          })
          // $.ajax({
          //   url: '/api/upimg',
          //   type: "POST",
          //   data: form,
          //   processData: false,
          //   contentType: false,
          //   beforeSend: function() {
          //     callback('before');
          //   },
          //   error: function() {
          //     callback('error');
          //   },
          //   success: function(url) {
          //     callback('success', url);
          //   }
          // })
          e.preventDefault();
        }
      }
    }
  },
  components: {
    MainLayout
  },
  mounted(){
    document.getElementById('addtag').onClick = function(e){
      e.preventDefault();
      alert();
    }
  }
}
</script>
