<template>
  <div>
    <form>
      <div class="detail">

        <input type="hidden" :value="data._id" name="id">
        <input type="hidden" :value="content" name="asset">
        <p v-show="!isEdit" class="title">{{data.title}}</p>
        <input v-show="isEdit" type="text" name="title" class="title" placeholder="请输入标题"   v-model="title">
        <div class="content" id="editor">

        </div>
      </div>
      <div class="submit" v-show="isEdit">
        <button type="submit" @click.prevent="edit">提交</button>
      </div>
    </form>

    <div class="ctl" v-show="!isEdit">
      <a class="butctl" @click="likeit($event)" :id="data._id" :disabled="islike" ref="likebox">
        <i class="fa fa-heart"></i>
      </a>
    </div>
  </div>
</template>
<style scoped>
  input{
    width:100%;
    height:40px;
    border:1px solid #ddd;
    border-radius:8px 8px 0px 0px;
    padding:0px 15px;
    -webkit-box-sizing: border-box;
    -moz-box-sizing: border-box;
    box-sizing: border-box;
  }
</style>
<script>
  import MainLayout from '../layouts/Main.vue'
  import E from 'wangeditor'
  import toastr from 'toastr'
  export default {
    created() {
      if(this.$router.history.current.name == 'edit'){
        this.isEdit = true;
      }
      this.getDetail(this.$route.params.id);
    },
    data(){
      return {
        isEdit:false,
        data:'',
        content:'',
        title:'',
        islike:false
      }
    },
    components: {
      MainLayout
    },
    methods:{
      edit(){
        this.$http.post('/api/edit', {
          title:this.title,
          asset:this.content,
          img:$('#editor').find('img').eq(0).attr('src')
        }).then((response) => {
                // success callback

              }, (response) => {
                // error callback
              });
      },
      getDetail(id){
        this.$http.get('/api/doc/'+id)
        .then(res => {
          this.data = res.data;
          this.title = this.data.title;
          this.init();
          this.isliked(this.data._id);
          this.browse();
        })
        .catch(e => {
          console.log(e)
        })
      },
      browse(){
        this.$http.post('/api/browse',{
          doc_id:this.data._id
        })
        .then(res => {
        })
        .catch(err => {
          this.toastr.error(`${err.message}`, 'ERROR!')
        })
      },
      init(){
        var editor = new E('#editor');
        var self = this;
        editor.customConfig.onchange = function (html) {
          self.content = html;
        }
        editor.create();

        editor.txt.html(this.data.asset);

        if(!this.isEdit)
          editor.$textElem.attr('contenteditable', false)
      },
      // 判断该文章是否已被当前用户收藏
      isliked(id){
        this.$http.post('/api/iflike',{
          doc_id:id
        })
        .then(res => {
          if(res.data.code == "11006"){
            this.islike = true;
            this.$refs.likebox.classList.add('liked');
          }


        })
        .catch(e => {
          console.log(e);
        })
      },
      likeit(e){
        var id = e.currentTarget.id;
        if(!this.islike)
          this.$http.post('/api/like',{
            doc_id:id
          })
        .then(res => {console.log(res.data);
          if(res.data.code == '11005')
            {   this.$refs.likebox.classList.add('like');toastr.success(res.data.msg)}
          else
            toastr.error(res.data.msg)

        })
        .catch(e => {
          console.log(e);
        })

      }
    },
    mounted() {

    }
  }
</script>
